function blkStruct = slblocks
%SLBLOCKS Define the Simulink library block representation.
%
%    Define the Simulink library block representation for the Vehicle
%    Network Toolbox Block Library.

%    SS 4-01-08
%    Copyright 2008 The MathWorks, Inc. 
%    $Revision: 1.1.6.1 $  $Date: 2008/06/16 17:06:03 $
%  
% blkStruct.Name    = sprintf('Vehicle\nNetwork\nToolbox');
% blkStruct.OpenFcn = 'vntlib';
% blkStruct.MaskInitialization = '';

% Define the library list for the Simulink Library browser.
% Return the name of the library model and the name for it
Browser(1).Library = 'BIT_MPC5644A_BOOT';
Browser(1).Name    = 'BIT-MPC5644A-Driver';
Browser(1).IsFlat  = 0;% Is this library "flat" (i.e. no subsystems)?

blkStruct.Browser = Browser;

% End of slblocks.m
